import React from 'react';
import { ArrowRight } from 'lucide-react';

export default function Hero() {
  return (
    <div className="relative bg-gradient-to-r from-blue-600 to-blue-800 text-white">
      <div className="container mx-auto px-4 py-16">
        <div className="grid lg:grid-cols-2 gap-8 items-center">
          <div>
            <h2 className="text-4xl font-bold mb-4">
              Tecnologia de Qualidade para Sua Vida
            </h2>
            <p className="text-lg mb-8">
              Encontre os melhores produtos eletrônicos com garantia e preço justo.
              Entrega rápida para Governador Valadares, BH e São Paulo.
            </p>
            <button className="bg-white text-blue-600 px-6 py-3 rounded-lg font-semibold flex items-center gap-2 hover:bg-blue-50 transition-colors">
              Ver Ofertas
              <ArrowRight size={20} />
            </button>
          </div>
          <div className="relative">
            <img
              src="https://images.unsplash.com/photo-1498049794561-7780e7231661?auto=format&fit=crop&q=80"
              alt="Eletrônicos modernos"
              className="rounded-lg shadow-xl"
            />
          </div>
        </div>
      </div>
    </div>
  );
}