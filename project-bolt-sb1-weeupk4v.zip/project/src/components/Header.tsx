import React from 'react';
import { ShoppingCart, Menu, Search, Phone } from 'lucide-react';

export default function Header() {
  return (
    <header className="bg-blue-600 text-white">
      {/* Top bar */}
      <div className="bg-blue-700 py-2">
        <div className="container mx-auto px-4 flex justify-between items-center">
          <p className="text-sm">Entrega para Governador Valadares, BH e São Paulo</p>
          <a href="tel:+553133333333" className="text-sm flex items-center gap-2">
            <Phone size={16} />
            (31) 3333-3333
          </a>
        </div>
      </div>
      
      {/* Main header */}
      <div className="container mx-auto px-4 py-4">
        <div className="flex items-center justify-between">
          <div className="flex items-center gap-8">
            <button className="lg:hidden">
              <Menu size={24} />
            </button>
            <h1 className="text-2xl font-bold">ABF Eletrônicos</h1>
          </div>
          
          {/* Search bar */}
          <div className="hidden lg:flex flex-1 max-w-xl mx-8">
            <div className="relative w-full">
              <input
                type="text"
                placeholder="Buscar produtos..."
                className="w-full py-2 px-4 rounded-lg text-gray-800 focus:outline-none focus:ring-2 focus:ring-blue-300"
              />
              <Search className="absolute right-3 top-2.5 text-gray-400" size={20} />
            </div>
          </div>
          
          {/* Cart */}
          <button className="relative">
            <ShoppingCart size={24} />
            <span className="absolute -top-2 -right-2 bg-red-500 text-white text-xs rounded-full w-5 h-5 flex items-center justify-center">
              0
            </span>
          </button>
        </div>
      </div>
      
      {/* Navigation */}
      <nav className="bg-blue-700">
        <div className="container mx-auto px-4">
          <ul className="flex space-x-6 py-3">
            <li><a href="#" className="hover:text-blue-200">Início</a></li>
            <li><a href="#" className="hover:text-blue-200">Produtos</a></li>
            <li><a href="#" className="hover:text-blue-200">Categorias</a></li>
            <li><a href="#" className="hover:text-blue-200">Sobre</a></li>
            <li><a href="#" className="hover:text-blue-200">Contato</a></li>
          </ul>
        </div>
      </nav>
    </header>
  );
}